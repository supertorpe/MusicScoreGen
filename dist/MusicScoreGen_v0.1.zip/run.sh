#!/bin/sh

JRE_HOME=/usr/lib/jvm/java-6-sun/jre

$JRE_HOME/bin/java $1 $2 $3 $4 $5 $6 $7 $8 $9 -jar MusicScoreGen.jar 
